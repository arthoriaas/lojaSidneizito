package br.com.sidneizito.loja.demo.controller;

import br.com.sidneizito.loja.demo.repository.ClientesRepository;
import br.com.sidneizito.loja.demo.repository.ComprasRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
public class MetodosLoja {
    @Autowired
    private ClientesRepository clientesRepository;
    @Autowired
    private ComprasRepository comprasRepository;

    private String query = "SELECT c.nome, sum(cm.valor_total) FROM COMPRAS cm JOIN CLIENTES c WHERE c.cpf = cm.cliente GROUP BY cliente ORDER BY sum(cm.VALOR_TOTAL) DESC";

}






