package br.com.sidneizito.loja.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class lojaApplicationTests {

    @Test
    void contextLoads() {
    }

}
